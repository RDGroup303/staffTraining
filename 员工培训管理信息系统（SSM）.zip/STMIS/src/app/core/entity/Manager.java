package app.core.entity;

import java.io.Serializable;

public class Manager implements Serializable {

}
