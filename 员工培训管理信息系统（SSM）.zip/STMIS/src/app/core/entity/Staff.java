package app.core.entity;

import java.io.Serializable;

public class Staff implements Serializable{

}
