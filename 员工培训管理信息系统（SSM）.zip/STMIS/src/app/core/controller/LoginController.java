package app.core.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class LoginController {
	@RequestMapping("/{formName}")
	public String loginForm(@PathVariable String formName){
		System.out.println(formName);
		//��̬��תҳ��
		return formName;
	}
}
