package app.core.service;

import app.core.entity.User;

public interface UserService {
	public User selectUser(User user);
}
