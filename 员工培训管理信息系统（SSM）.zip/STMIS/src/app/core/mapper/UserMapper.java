package app.core.mapper;

import app.core.entity.User;

public interface UserMapper {
	public User selectUser(User user);
}
